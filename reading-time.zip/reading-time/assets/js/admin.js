(function($) {
 $("#clear-calculations").click(function (){

     $.ajax({
         url:readingtime_object.ajax_url,
         type:"POST",
         data: {
             action:'set_calculations',
         },   success: function(response){
                $("#about-calculations").html(response);
         }, error: function(data){

         }
     });
 });
})(jQuery);