(function($) {
 $("#clear-calculations").click(function (){
    alert(readingtime_object.ajax_url);
     $.ajax({
         url:readingtime_object.ajax_url,
         type:"POST",
         dataType:'type',
         data: {
             action:'set_calculations',
         },   success: function(response){

         }, error: function(data){

         }
     });
 });
})(jQuery);